package LeenSara;

//this class is for the routes between cities 
public class Node implements Comparable<Node> {
	
	private int cityId;
	private int route;
	Node parentNode;


	public Node(int cityId, int route, Node parentNode) {
		super();
		this.cityId = cityId;
		this.route = route;
		this.parentNode = parentNode;
	}


	public int getCityId() {
		return cityId;
	}


	public void setCityId(int cityId) {
		this.cityId = cityId;
	}


	public int getRoute() {
		return route;
	}


	public void setRoute(int route1) {
		this.route = route1;
	}
 
	
	
	public Node getParentNode() {
		return parentNode;
	}


	public void setParentNode(Node parentNode) {
		this.parentNode = parentNode;
	}


	@Override
	public int compareTo(Node node) {
		// TODO Auto-generated method stub
		return  route - node.route;
	}



}
