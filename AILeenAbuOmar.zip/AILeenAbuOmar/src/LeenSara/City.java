package LeenSara;

public class City implements Comparable<City> {

	private int cityID; // Index number of city 
	private int cost; // path cost
	private int heuristicEvaluation; // estimated cost
	City parentCity; // parent of a node


	public City(int cityID, int cost, int heuristicEvaluation, City parentCity) {
		super();
		this.cityID = cityID;
		this.cost = cost;
		this.heuristicEvaluation = heuristicEvaluation;
		this.parentCity = parentCity;
	}

	public int getCityID() {
		return cityID;
	}

	public void setCityID(int cityID) {
		this.cityID = cityID;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public int getHeuristicEvaluation() {
		return heuristicEvaluation;
	}

	public void setHeuristicEvaluation(int heuristicEvaluation) {
		this.heuristicEvaluation = heuristicEvaluation;
	}

	public City getParentCity() {
		return parentCity;
	}

	public void setParentCity(City parentCity) {
		this.parentCity = parentCity;
	}

	@Override
	public String toString() {
		return "City [cityID=" + cityID + ", cost=" + cost + ", heuristicEvaluation=" + heuristicEvaluation
				+ ", parentCity=" + parentCity + "]";
	}

	// Index numbers of cities 
	static String indexOfCities(int id) {
		switch (id) {
		case 0:
			return "Aka";
		case 1:
			return "Bethlehem";
		case 2:
			return "Dura";
		case 3:
			return "Haifa";
		case 4:
			return "Halhoul";
		case 5:
			return "Hebron";
		case 6:
			return "Jenin";
		case 7:
			return "Jericho";
		case 8:
			return "Jerusalem";
		case 9:
			return "Nablus";
		case 10:
			return "Nazareth";
		case 11:
			return "Qalqilya";
		case 12:
			return "Ramallah";
		case 13:
			return "Ramleh";
		case 14:
			return "Sabastia";
		case 15:
			return "Safad";
		case 16:
			return "Salfit";
		case 17:
			return "Tubas";
		case 18:
			return "Tulkarm";
		case 19:
			return "Yafa";

		}
		return null;
	}

	@Override
	public int compareTo(City node) {
		return heuristicEvaluation - node.heuristicEvaluation;
	}
}
