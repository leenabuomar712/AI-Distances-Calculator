package LeenSara;

import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Stack;

public class SearchAlgorithms {
	public static ArrayList<City> orderOfCities = new ArrayList<City>();
	public static ArrayList<City> path = new ArrayList<City>();
	static Stack<City> reversePath = new Stack<>();
	static City goalState = null;

	// the first type of Searching Algorithm is Uniform Cost
	public static ArrayList<City> uniformCostAlgorithm(int initialId, ArrayList<Integer> goalsId) {
		clearPreviousCities(true);// calling the function clearPreviousCities which deletes the data of the cities
									// stored in the arraylist from the last algorithm used
		// priorityQueue
		PriorityQueue<City> fringe = new PriorityQueue<>(); // initializing a priority queue to store the cities into a
															// fringe
		City initialCity = new City(initialId, 0, 0, null); // creating an object initialCity from the class City
		fringe.add(initialCity); // adding the initialCity selected into the fringe
		do // while the fringe is not empty (which there exists cities that could be
			// chosen)
		{
			// poll method in the priority queue is for taking the currentCity from the
			// fringe with deleting it.
			City currentCity = fringe.poll(); // polling the currentCity from the Fringe
			orderOfCities.add(currentCity);// adding the selected city from the fringe to the arraylist orderOfCities
			int currentID = currentCity.getCityID();
			if (goalsId.contains(currentID)) // if the user selected a goal which is as same as the
												// current city id, then the goal state will
			{
				goalState = currentCity;
				break;
			}
			// the following for loop is for doing the process for the UCS algorithm by only
			// checking the real cost for the nodes, will the heuristic value will not be
			// required so it was filled by zero in the City object (nextCity object)
			for (int i = 0; i < Main.costValues[currentID].size(); i++) {
				City nextCity = new City(Main.costValues[currentID].get(i).getCityId(),
						currentCity.getCost() + Main.costValues[currentID].get(i).getRoute1(), 0, currentCity);
				fringe.add(nextCity); // adding the nextCity successor into the fringe

			}
		} while (fringe.size() > 0);
		return reversePathStack(goalState, path);

	}

	// the second type of Searching Algorithm is Greedy
	public static ArrayList<City> GreedyAlgorithm(int initialId, ArrayList<Integer> goalsId) {
		clearPreviousCities(true);// calling the function clearPreviousCities which deletes the data of the cities
									// stored in the arraylist from the last algorithm used
		PriorityQueue<City> fringe = new PriorityQueue<>();
		City initialCity = new City(initialId, 0, minimumHeuristicValue(initialId, goalsId), null);
		fringe.add(initialCity);
		do {
			City currentCity = fringe.poll();
			orderOfCities.add(currentCity);
			int currentID = currentCity.getCityID();
			if (goalsId.contains(currentCity.getCityID())) {
				goalState = currentCity;
				break;
			}
			// the following for loop is for doing the process for the Greedy algorithm by only
			// checking the estimation cost (heuristic value)for the nodes, will the real cost will not be
			// required so it was filled by zero in the City object (nextCity object)
			for (int i = 0; i < Main.costValues[currentID].size(); i++) {
							City nextCity = new City(Main.costValues[currentID].get(i).getCityId(),
							0, minimumHeuristicValue(Main.costValues[currentID].get(i).getCityId(), goalsId), currentCity);
							fringe.add(nextCity); // adding the nextCity successor into the fringe

			}
		} while (fringe.size() > 0);
		return reversePathStack(goalState, path);
	}

	// the third type of Searching Algorithm is A*, when path cost = walking distance and estimated cost (heuristic) = aerial distance
	public static ArrayList<City> AStarAlgorithm(int initialId, ArrayList<Integer> goalsId) {
		clearPreviousCities(true);// calling the function clearPreviousCities which deletes the data of the cities
		// stored in the arraylist from the last algorithm used
		PriorityQueue<City> fringe = new PriorityQueue<>();
		City initialCity = new City(initialId, 0, minimumHeuristicValue(initialId, goalsId), null);
		fringe.add(initialCity);

		do {
			City currentCity = fringe.poll();
			int currentID = currentCity.getCityID();
			if (true) {
				orderOfCities.add(currentCity);

			}
			if (goalsId.contains(currentCity.getCityID())) {
				goalState = currentCity;
				break;
			}
			// the following for loop is for doing the process for the A* algorithm by 
						// checking the estimation cost (heuristic value) and the real cost for the nodes
						for (int i = 0; i < Main.costValues[currentID].size(); i++) {
										City nextCity = new City(Main.costValues[currentID].get(i).getCityId(),
										currentCity.getCost() + Main.costValues[currentID].get(i).getRoute2(),
										minimumHeuristicValue(Main.costValues[currentID].get(i).getCityId(), goalsId), currentCity);
										fringe.add(nextCity); // adding the nextCity successor into the fringe

						}

		} while (fringe.size() > 0);
		return reversePathStack(goalState, path);
	}

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// the fourth type of Searching Algorithm is A*, when path cost = street distance and estimated cost (heuristic) = walking distance
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// a function for giving the minimum heuristic value from the arrayList
	static int minimumHeuristicValue(int currentId, ArrayList<Integer> goalsId) {
		int minValue = Main.HeuristicValues[goalsId.get(0)].get(currentId); // defining a variable initialized with the
																			// first heuristic value in the array with
																			// the city id, and start checking each
																			// element in the array by the next for loop
																			// and if the loop found a heuristic value
																			// less than the current one, the variable
																			// will be equal the new minimum value
		for (int i = 1; i < goalsId.size(); i++)
			while (Main.HeuristicValues[goalsId.get(i)].get(currentId) < minValue)
				minValue = Main.HeuristicValues[goalsId.get(i)].get(currentId); // the new minimum heuristic will be
																				// filled in the variable minValue
		return minValue;

	}

	// a function for returning the reversed path from the initial to the end state
	static ArrayList<City> reversePathStack(City goalState, ArrayList<City> path) {
		// when we reached to goal city
		while (goalState != null) {
			reversePath.push(goalState); // to get the last city put in the array list of the path cities
			goalState = goalState.parentCity; // points at the previous city in the stack
		}
		while (reversePath.size() > 0)// while there exists cities in the arraylist named reversePath
			path.add(reversePath.pop()); // to add the cities that were taken from the arrayList reversePath into the
											// arrayList named path
		return path;
	}

	// a function for deleting the data of the cities stored in the arraylist from
	// the last algorithm used
	static void clearPreviousCities(Boolean clear) // boolean attribute
	{
		if (clear) // if (true)
			orderOfCities.clear(); // clear the arrayList named orderOfCities
		path.clear(); // clear the arrayList named path
		goalState = null; // the arrayList is empty now to allow the user to choose a new goal
	}
}
