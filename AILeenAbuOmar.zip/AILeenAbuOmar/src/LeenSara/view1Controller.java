package LeenSara;
/*
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.input.MouseEvent;

public class view1Controller {

    @FXML
    private Button Search;

    @FXML
    private Label akaLabel;

    @FXML
    private RadioButton akaRadio;

    @FXML
    private Label bethlehemLabel;

    @FXML
    private RadioButton bethlehemRadio;

    @FXML
    private Button delete;

    @FXML
    private Label duraLabel;

    @FXML
    private RadioButton duraRadio;

    @FXML
    private Button goalState;

    @FXML
    private Label haifaLabel;

    @FXML
    private RadioButton haifaRadio;

    @FXML
    private Label halhoulLabel;

    @FXML
    private RadioButton halhoulRadio;

    @FXML
    private Label hebronLabel;

    @FXML
    private RadioButton hebronRadio;

    @FXML
    private Button initialState;

    @FXML
    private Label jeninLabel;

    @FXML
    private RadioButton jeninRadio;

    @FXML
    private Label jerichoLabel;

    @FXML
    private RadioButton jerichoRadio;

    @FXML
    private Label jerusalemLabel;

    @FXML
    private RadioButton jerusalemRadio;

    @FXML
    private Label nablusLabel;

    @FXML
    private RadioButton nablusRadio;

    @FXML
    private Label nazarethLabel;

    @FXML
    private RadioButton nazarethRadio;

    @FXML
    private Button next;

    @FXML
    private Label qalqilyaLabel;

    @FXML
    private RadioButton qalqilyaRadio;

    @FXML
    private Label ramallahLabel;

    @FXML
    private RadioButton ramallahRadio;

    @FXML
    private Label ramlehLabel;

    @FXML
    private RadioButton ramlehRadio;

    @FXML
    private Label sabastiaLabel;

    @FXML
    private RadioButton sabastiaRadio;

    @FXML
    private Label safadLabel;

    @FXML
    private RadioButton safadRadio;

    @FXML
    private Label salfitLabel;

    @FXML
    private RadioButton salfitRadio;

    @FXML
    private ComboBox<?> searchAlgorithmType;

    @FXML
    private Label tubasLabel;

    @FXML
    private RadioButton tubasRadio;

    @FXML
    private Label tulkarmLabel;

    @FXML
    private RadioButton tulkarmRadio;

    @FXML
    private Label yafaLabel;

    @FXML
    private RadioButton yafaRadio;

    @FXML
    void Search(ActionEvent event) {

    }

    @FXML
    void delete(ActionEvent event) {

    }

    @FXML
    void goalState(ActionEvent event) {

    }

    @FXML
    void initialState(ActionEvent event) {

    }

    @FXML
    void next(ActionEvent event) {

    }

    @FXML
    void pressLabel(MouseEvent event) {

    }

    @FXML
    void searchCombo(ActionEvent event) {

    }

    @FXML
    void selectRadio(ActionEvent event) {

    }

}
*/
