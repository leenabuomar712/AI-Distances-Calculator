package LeenSara;
//**************************************************************************************************
//*************************************Leen Abu Omar 1190113
//*************************************Sara Issa 1190673
//*************************************************************************************************

import java.util.ArrayList;

public class Main {
	
	static int numberOfCities = 20;
	// aerial distance
	@SuppressWarnings("unchecked")
	public static ArrayList<Integer>[] HeuristicValues = new ArrayList[numberOfCities];
	// street distance
	@SuppressWarnings("unchecked")
	public static ArrayList<Node>[] costValues1 = new ArrayList[numberOfCities];
	// walking distance
	@SuppressWarnings("unchecked")
	public static ArrayList<Node>[] costValues2 = new ArrayList[numberOfCities];

	public static void main(String[] args) {

	}
}
